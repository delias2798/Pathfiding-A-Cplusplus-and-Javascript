//
// Created by jonathan on 06/09/18.
//

#include "aSearch.h"
#include<bits/stdc++.h>

#define ROW 9
#define COL 10

using namespace std;

// Devuelve verdadero si el número de fila y columna está dentro del rango.
bool aSearch::isValid(int row, int col) {
    return (row >= 0) && (row < ROW) &&
           (col >= 0) && (col < COL);
}

// Devuelve verdadero si la celda no está bloqueada, es falso.
bool aSearch::isUnBlocked(int (*grid)[10], int row, int col) {
    if (grid[row][col] == 1)
        return (true);
    else
        return (false);
}

bool aSearch::isDestination(int row, int col, Pair dest) {
    if (row == dest.first && col == dest.second)
        return (true);
    else
        return (false);
}

// Retorna utilizando la formula de distancia.
double aSearch::calculateHValue(int row, int col, Pair dest) {
    return ((double) sqrt((row - dest.first) * (row - dest.first)
                          + (col - dest.second) * (col - dest.second)));
}

void aSearch::tracePath(cell (*cellDetails)[10], Pair dest) {

    printf("\nThe Path is ");
    int row = dest.first;
    int col = dest.second;
    stack<Pair> Path;

    while (!(cellDetails[row][col].parent_i == row
             && cellDetails[row][col].parent_j == col)) {
        Path.push(make_pair(row, col));
        int temp_row = cellDetails[row][col].parent_i;
        int temp_col = cellDetails[row][col].parent_j;
        row = temp_row;
        col = temp_col;
    }

    Path.push(make_pair(row, col));
    while (!Path.empty()) {
        pair<int, int> p = Path.top();
        Path.pop();
        printf("-> (%d,%d) ", p.first, p.second);
    }

    return;

}

void aSearch::aStarSearch(int (*grid)[10], Pair src, Pair dest) {

    // Si la fuente está fuera de rango.
    if (isValid(src.first, src.second) == false) {
        printf("Source is invalid\n");
        return;
    }

    // Si el destino está fuera de rango.
    if (isValid(dest.first, dest.second) == false) {
        printf("Destination is invalid\n");
        return;
    }

    // Si la fuente o el destino está bloqueado.
    if (isUnBlocked(grid, src.first, src.second) == false ||
        isUnBlocked(grid, dest.first, dest.second) == false) {
        printf("Source or the destination is blocked\n");
        return;
    }

    // Si la celda de destino es la misma que la celda fuente.
    if (isDestination(src.first, src.second, dest) == true) {
        printf("We are already at the destination\n");
        return;
    }

    // Creea una lista cerrada y la inicializa en falso, lo que significa que aún no se ha incluido ninguna celda.
    // Esta lista cerrada se implementa como una matriz booleana 2D.
    bool closedList[ROW][COL];
    memset(closedList, false, sizeof(closedList));

    // Declara una matriz 2D para contener los detalles de la celda.
    cell cellDetails[ROW][COL];
    int i, j;
    for (i = 0; i < ROW; i++) {
        for (j = 0; j < COL; j++) {
            cellDetails[i][j].f = FLT_MAX;
            cellDetails[i][j].g = FLT_MAX;
            cellDetails[i][j].h = FLT_MAX;
            cellDetails[i][j].parent_i = -1;
            cellDetails[i][j].parent_j = -1;
        }
    }

    // Inicializando los parámetros del nodo inicial.
    i = src.first, j = src.second;
    cellDetails[i][j].f = 0.0;
    cellDetails[i][j].g = 0.0;
    cellDetails[i][j].h = 0.0;
    cellDetails[i][j].parent_i = i;
    cellDetails[i][j].parent_j = j;

    /*
     Crea una lista abierta con información como-
      <f, <i, j >>
      donde f = g + h,
      y yo, j son el índice de fila y columna de esa celda
      Tenga en cuenta que 0 <= i <= ROW-1 & 0 <= j <= COL-1
      Esta lista abierta se implementa como un conjunto de pares de pares.
     */
    set<pPair> openList;

    // Coloca la celda inicial en la lista abierta y configura su 'f' como 0.
    openList.insert(make_pair(0.0, make_pair(i, j)));

    // Establecemos este valor booleano como falso ya que inicialmente no se alcanza el destino.
    bool foundDest = false;

    while (!openList.empty()) {
        pPair p = *openList.begin();

        // Elimina este vértice de la lista abierta.
        openList.erase(openList.begin());

        // Agrega este vértice a la lista cerrada.
        i = p.second.first;
        j = p.second.second;
        closedList[i][j] = true;

        /*
         Generando todos los 8 sucesores de esta celda

             N.W   N   N.E
               \   |   /
                \  |  /
             W----Cell----E
                  / | \
                /   |  \
             S.W    S   S.E

         Celda --> PoppedCell (i, j)
         N -->  North       (i-1, j)
         S -->  South       (i+1, j)
         E -->  East        (i, j+1)
         W -->  West           (i, j-1)
         N.E--> North-East  (i-1, j+1)
         N.W--> North-West  (i-1, j-1)
         S.E--> South-East  (i+1, j+1)
         S.W--> South-West  (i+1, j-1)*/

        // Para almacenar 'f', 'g' y 'h' de los 8 sucesores.
        double fNew, gNew, hNew;

        //----------- 1st Successor (North) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i - 1, j) == true) {
            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i - 1, j, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i - 1][j].parent_i = i;
                cellDetails[i - 1][j].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }
                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i - 1][j] == false &&
                     isUnBlocked(grid, i - 1, j) == true) {
                gNew = cellDetails[i][j].g + 1.0;
                hNew = calculateHValue(i - 1, j, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal de este cuadro.
                // Registra los costos f, g, y h de la celda cuad// Solo procesa esta celda si esta es válida.rada.
                // Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i - 1][j].f == FLT_MAX ||
                    cellDetails[i - 1][j].f > fNew) {
                    openList.insert(make_pair(fNew,
                                              make_pair(i - 1, j)));

                    // Actualiza los detalles de esta celda.
                    cellDetails[i - 1][j].f = fNew;
                    cellDetails[i - 1][j].g = gNew;
                    cellDetails[i - 1][j].h = hNew;
                    cellDetails[i - 1][j].parent_i = i;
                    cellDetails[i - 1][j].parent_j = j;
                }
            }
        }

        //----------- 2nd Successor (South) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i + 1, j) == true) {
            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i + 1, j, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i + 1][j].parent_i = i;
                cellDetails[i + 1][j].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }
                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i + 1][j] == false &&
                     isUnBlocked(grid, i + 1, j) == true) {
                gNew = cellDetails[i][j].g + 1.0;
                hNew = calculateHValue(i + 1, j, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal de este cuadro.
                // Registra los costos f, g, y h de la celda cuad// Solo procesa esta celda si esta es válida.rada.
                // Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i + 1][j].f == FLT_MAX ||
                    cellDetails[i + 1][j].f > fNew) {
                    openList.insert(make_pair(fNew, make_pair(i + 1, j)));

                    // Actualiza los detalles de esta celda.
                    cellDetails[i + 1][j].f = fNew;
                    cellDetails[i + 1][j].g = gNew;
                    cellDetails[i + 1][j].h = hNew;
                    cellDetails[i + 1][j].parent_i = i;
                    cellDetails[i + 1][j].parent_j = j;
                }
            }
        }

        //----------- 3rd Successor (East) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i, j + 1) == true) {
            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i, j + 1, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i][j + 1].parent_i = i;
                cellDetails[i][j + 1].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }

                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i][j + 1] == false &&
                     isUnBlocked(grid, i, j + 1) == true) {
                gNew = cellDetails[i][j].g + 1.0;
                hNew = calculateHValue(i, j + 1, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal de este cuadro.
                // Registra los costos f, g, y h de la celda cuad// Solo procesa esta celda si esta es válida.rada.
                // Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i][j + 1].f == FLT_MAX ||
                    cellDetails[i][j + 1].f > fNew) {
                    openList.insert(make_pair(fNew,
                                              make_pair(i, j + 1)));

                    // Actualiza los detalles de esta celda.
                    cellDetails[i][j + 1].f = fNew;
                    cellDetails[i][j + 1].g = gNew;
                    cellDetails[i][j + 1].h = hNew;
                    cellDetails[i][j + 1].parent_i = i;
                    cellDetails[i][j + 1].parent_j = j;
                }
            }
        }

        //----------- 4th Successor (West) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i, j - 1) == true) {
            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i, j - 1, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i][j - 1].parent_i = i;
                cellDetails[i][j - 1].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }

                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i][j - 1] == false &&
                     isUnBlocked(grid, i, j - 1) == true) {
                gNew = cellDetails[i][j].g + 1.0;
                hNew = calculateHValue(i, j - 1, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal de este cuadro.
                // Registra los costos f, g, y h de la celda cuad// Solo procesa esta celda si esta es válida.rada.
                // Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i][j - 1].f == FLT_MAX ||
                    cellDetails[i][j - 1].f > fNew) {
                    openList.insert(make_pair(fNew,
                                              make_pair(i, j - 1)));

                    // Actualiza los detalles de esta celda.
                    cellDetails[i][j - 1].f = fNew;
                    cellDetails[i][j - 1].g = gNew;
                    cellDetails[i][j - 1].h = hNew;
                    cellDetails[i][j - 1].parent_i = i;
                    cellDetails[i][j - 1].parent_j = j;
                }
            }
        }

        //----------- 5th Successor (North-East) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i - 1, j + 1) == true) {
            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i - 1, j + 1, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i - 1][j + 1].parent_i = i;
                cellDetails[i - 1][j + 1].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }

                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i - 1][j + 1] == false &&
                     isUnBlocked(grid, i - 1, j + 1) == true) {
                gNew = cellDetails[i][j].g + 1.414;
                hNew = calculateHValue(i - 1, j + 1, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal de este cuadro.
                // Registra los costos f, g, y h de la celda cuadrada.
                // Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i - 1][j + 1].f == FLT_MAX ||
                    cellDetails[i - 1][j + 1].f > fNew) {
                    openList.insert(make_pair(fNew,
                                              make_pair(i - 1, j + 1)));

                    // Actualiza los detalles de esta celda.
                    cellDetails[i - 1][j + 1].f = fNew;
                    cellDetails[i - 1][j + 1].g = gNew;
                    cellDetails[i - 1][j + 1].h = hNew;
                    cellDetails[i - 1][j + 1].parent_i = i;
                    cellDetails[i - 1][j + 1].parent_j = j;
                }
            }
        }

        //----------- 6th Successor (North-West) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i - 1, j - 1) == true) {
            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i - 1, j - 1, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i - 1][j - 1].parent_i = i;
                cellDetails[i - 1][j - 1].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }

                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i - 1][j - 1] == false &&
                     isUnBlocked(grid, i - 1, j - 1) == true) {
                gNew = cellDetails[i][j].g + 1.414;
                hNew = calculateHValue(i - 1, j - 1, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal de este cuadro.
                // Registra los costos f, g, y h de la celda cuadrada.
                // Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i - 1][j - 1].f == FLT_MAX ||
                    cellDetails[i - 1][j - 1].f > fNew) {
                    openList.insert(make_pair(fNew, make_pair(i - 1, j - 1)));
                    // Actualiza los detalles de esta celda.
                    cellDetails[i - 1][j - 1].f = fNew;
                    cellDetails[i - 1][j - 1].g = gNew;
                    cellDetails[i - 1][j - 1].h = hNew;
                    cellDetails[i - 1][j - 1].parent_i = i;
                    cellDetails[i - 1][j - 1].parent_j = j;
                }
            }
        }

        //----------- 7th Successor (South-East) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i + 1, j + 1) == true) {
            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i + 1, j + 1, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i + 1][j + 1].parent_i = i;
                cellDetails[i + 1][j + 1].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }

                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i + 1][j + 1] == false &&
                     isUnBlocked(grid, i + 1, j + 1) == true) {
                gNew = cellDetails[i][j].g + 1.414;
                hNew = calculateHValue(i + 1, j + 1, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal de este cuadro.
                // Registra los costos f, g, y h de la celda cuadrada.
                // Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i + 1][j + 1].f == FLT_MAX ||
                    cellDetails[i + 1][j + 1].f > fNew) {
                    openList.insert(make_pair(fNew,
                                              make_pair(i + 1, j + 1)));

                    // Actualiza los detalles de esta celda.
                    cellDetails[i + 1][j + 1].f = fNew;
                    cellDetails[i + 1][j + 1].g = gNew;
                    cellDetails[i + 1][j + 1].h = hNew;
                    cellDetails[i + 1][j + 1].parent_i = i;
                    cellDetails[i + 1][j + 1].parent_j = j;
                }
            }
        }

        //----------- 8th Successor (South-West) ------------//

        // Solo procesa esta celda si esta es válida.
        if (isValid(i + 1, j - 1) == true) {

            // Si la celda destino es la misma que el sucesor actual.
            if (isDestination(i + 1, j - 1, dest) == true) {
                // Establece el padre de la celda destino.
                cellDetails[i + 1][j - 1].parent_i = i;
                cellDetails[i + 1][j - 1].parent_j = j;
                printf("The destination cell is found\n");
                tracePath(cellDetails, dest);
                foundDest = true;
                return;
            }

                // Si el sucesor ya está cerrado o si está bloqueado, lo ignora.
                // De lo contrario, realiza lo siguiente.
            else if (closedList[i + 1][j - 1] == false &&
                     isUnBlocked(grid, i + 1, j - 1) == true) {
                gNew = cellDetails[i][j].g + 1.414;
                hNew = calculateHValue(i + 1, j - 1, dest);
                fNew = gNew + hNew;

                // Si no está en la lista abierta, la agrega a la lista abierta. Hace que el cuadro actual sea el principal
                // Registra los costos f, g, y h de la celda cuadrada.
                //Si ya está en la lista abierta, verifica si esta ruta a ese destino es mejor, usando 'f' costo como medida.
                if (cellDetails[i + 1][j - 1].f == FLT_MAX ||
                    cellDetails[i + 1][j - 1].f > fNew) {
                    openList.insert(make_pair(fNew,
                                              make_pair(i + 1, j - 1)));

                    // Actualizando los detalles de esta celda
                    cellDetails[i + 1][j - 1].f = fNew;
                    cellDetails[i + 1][j - 1].g = gNew;
                    cellDetails[i + 1][j - 1].h = hNew;
                    cellDetails[i + 1][j - 1].parent_i = i;
                    cellDetails[i + 1][j - 1].parent_j = j;
                }
            }
        }
    }
    // Cuando no se encuentra la celda destino y la lista abierta está vacía, concluimos que no pudimos llegar a la celda de destino.
    // Esto puede suceder cuando no hay forma de llegar a la celda destino.
    if (foundDest == false) {
        printf("Failed to find the Destination Cell\n");
    }

    return;
}