//
// Created by jonathan on 06/09/18.
//

#ifndef ASEARCHASTERISK_ASEARCH_H
#define ASEARCHASTERISK_ASEARCH_H


#include<bits/stdc++.h>

#define ROW 9
#define COL 10

using namespace std;

typedef pair<int, int> Pair;

// Creando un acceso directo a los tipos par.
typedef pair<double, pair<int, int>> pPair;

struct cell {
    // Indice de fila y columna del padre.
    // Teniendo en cuenta que: 0 <= i <= FIL-1 & 0 <= j <= COL-1
    int parent_i, parent_j;
    // f = g + h
    double f, g, h;
};

class aSearch {

private:

    // Una función de utilidad para verificar si una celda determinada (fila, col) es una celda válida o no.
    /**
     *
     * @param row
     * @param col
     * @return
     */
    bool isValid(int row, int col);

    // Una función de utilidad para verificar si la celda dada está bloqueada o no.
    /**
     *
     * @param grid
     * @param row
     * @param col
     * @return
     */
    bool isUnBlocked(int grid[][COL], int row, int col);

    // Una función de utilidad para verificar si se ha alcanzado o no la celda de destino.
    /**
     *
     * @param row
     * @param col
     * @param dest
     * @return
     */
    bool isDestination(int row, int col, Pair dest);

    // Una función de utilidad para calcular la heurística 'h'.
    /**
     *
     * @param row
     * @param col
     * @param dest
     * @return
     */
    double calculateHValue(int row, int col, Pair dest);

    // Una función de utilidad para rastrear la ruta desde la fuente hasta el destino.
    /**
     *
     * @param cellDetails
     * @param dest
     */
    void tracePath(cell cellDetails[][COL], Pair dest);

public:

    // Una función para encontrar la ruta más corta entre una celda fuente dada y una celda de destino de acuerdo con el algoritmo de búsqueda A *
    /**
     *
     * @param grid
     * @param src
     * @param dest
     */
    void aStarSearch(int grid[][COL], Pair src, Pair dest);

};

#endif //ASEARCHASTERISK_ASEARCH_H
