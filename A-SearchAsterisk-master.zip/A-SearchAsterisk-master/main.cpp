#include<bits/stdc++.h>
#include "AClass/aSearch.h"
#define ROW 9
#define COL 10

using namespace std;

int main()
{
    // Celda de pruebra.
    // Puede modificarse para mas casos de prueba.
    int grid[ROW][COL] =
            {
                    { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
                    { 1, 0, 1, 1, 1, 1, 1, 1, 1, 1 },
                    { 1, 1, 0, 1, 1, 1, 1, 1, 1, 1 },
                    { 1, 1, 1, 0, 1, 1, 1, 1, 1, 1 },
                    { 1, 1, 1, 1, 0, 1, 1, 1, 1, 1 },
                    { 1, 1, 1, 1, 1, 0, 1, 1, 1, 1 },
                    { 1, 1, 1, 1, 1, 1, 0, 1, 1, 1 },
                    { 1, 1, 1, 1, 1, 1, 1, 0, 1, 1 },
                    { 1, 1, 1, 1, 1, 1, 1, 1, 0, 1 }
            };

    // Estableciendo la fuente en la esquina inferior izquierda.
    // Pueden modificarse para los casos de prueba.
    Pair src = make_pair(8, 9);

    // Estableciendo el destino en la esquina superior izquierda.
    // Pueden modificarse para los casos de prueba.
    Pair dest = make_pair(0, 0);

    aSearch asearch1;

    asearch1.aStarSearch(grid, src, dest);

    return(0);
}